const orderData = 
   [
    {
    ImageURL: "https://cdn.shopify.com/s/files/1/2869/2938/products/TartanCeramicspink.png?v=1642001744",
    ItemID: 4087,
    Name: "CERAMIC JUG WITH STRIPE DETAIL , GREEN ",
    Price: 75,
    Quantity: 1},
    { ImageURL: "https://cdn.shopify.com/s/files/1/2869/2938/products/PinkTrimCaneShademedium.png?v=1642074906",
    ItemID: 3422,
    Name: "CANE LAMPSHADE WITH PINK TRIM, MEDIUM",
    Price: 200,
    Quantity: 2},
    {ImageURL: "https://cdn.shopify.com/s/files/1/2869/2938/products/Napkinsset.png?v=1641997776",
    ItemID: 3516,
    Name: "SCALLOP TRIM LINEN NAPKINS, SET OF 6, MIXED ",
    Price: 92,
    Quantity: 1},
    {ImageURL: "https://cdn.shopify.com/s/files/1/2869/2938/products/CandleDoclilac.png?v=1642089751",
    ItemID: 2326,
    Name: "PACK OF LILAC BEESWAX CANDLES",
    Price: 42,
    Quantity: 1},

   ] 

export default orderData